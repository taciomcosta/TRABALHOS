<?php session_start();?>
<html>
	<head>
		<title>Cadastro de Produto</title>
                <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
			<!--<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />-->
                <link rel="shortcut icon" href="favicon.ico">
                <link rel="stylesheet" href="../css/style.css">
	</head>
	
	<body>
              <?php
                  if (isset($_SESSION["id"]) == 0){
                     header("location: ../index.php");
                   } 
                  ?> 
        <div class="topo">
            <?php
	            include('head.php');
            ?>
        </div>

        <div class="menutop">
        </div>
            <div class="conteudo">
				<div class="colunamenu">
					<div id ="menu" >
						<ul>
							<li><h2>Menu</h2> </li>
							<li><a href="telaCategoria.php">Controle de Categoria</a> </li>
							<li><a href="telaUsuario.php">Controle de Usuario</a> </li>
                                                        <li><a href="index.php">Voltar </a> </li>
						</ul>
					</div>
				</div>
				<div class="center"> 
                                     <h1>Cadastro de Produto</h1>
		<br>
		<table border="0">
                
		      <form action="cadProduto.php" method="post" enctype="multipart/form-data">
			<tr>
				<td>ID do Produto:
				<td>
					<?php $tabela = "produto";
					include 'funcUltimoId.php'?>
					<input type='text' style="font-weight:bold" readonly name="idProduto" maxlength='5' size='25' value='<?php echo $idNovo; ?>'/>
			</tr>
			
			<tr>
				<td>Nome:
				<td><input type="text" name="nome" size="40"/>
			</tr>
			
			<tr>
				<td>Descri&ccedil;&atilde;o:
				<td><input type="text" name="descricao" size="40"/>
			</tr>
			
			<tr>
				<td>Destaque:
				<td><input type="checkbox" name="destaque" value="S"/>Produto em Destaque
			</tr>
			
			<tr>
				<td>Categoria:
				<td>
					
					<?php 
						include 'funcListaCategoria.php'; 
					?>
				</td>
			</tr>
			
			<tr>
				<td>Sexo:
				<td><input type="radio" name="sexo" value="M" checked>Masculino  
					<input type="radio" name="sexo" value="F">Feminino  
					<input type="radio" name="sexo" value="A">Ambos
	
				</td>
			</tr>
			
			<tr>
				<td>Faixa Etaria:
				<td><input type="text" name="faixaEtaria" size="40"/>
			</tr>			
			<tr>
				<td>Pre&ccedil;o:
				<td><input type="text" name="preco" size="40"/>
			</tr>
			
			<tr>
				<td>Desconto:
				<td><input type="text" name="desconto" size="40"/>
			</tr>
			
			<tr>
				<td>Parcela Maxima:
				<td><input type="text" name="parcela" size="40"/>
			</tr>
			
			<tr>
				<td>Fabricante:
				<td><input type="text" name="fabricante" size="40"/>
			</tr>
			
			<tr>
				<td>Qdade Estoque:
				<td><input type="text" name="qdadeEstoque" size="40"/>
			</tr>
			
			<tr>
				<td>Foto da Lista:
				<td><input type="file" name="fotoLista"/>
			</tr>
			
			<tr>
				<td>Foto da Descri&ccedil;&atilde;o:
				<td><input type="file" name="fotoDescricao"/>
			</tr>
			
			<tr>  
				<td  align="center"><input type="submit" name="salvar" value="Salvar"/>
				<td> <input type="reset" name="limpar" value="Limpar Dados"/>
			
			</tr>
			
		</form>
		</table>

				</div>
				<div class="footer">
					
					<?php
						include('../complemento/footer.php');
					?>
				</div>
			</div>
	</body>

</html>
