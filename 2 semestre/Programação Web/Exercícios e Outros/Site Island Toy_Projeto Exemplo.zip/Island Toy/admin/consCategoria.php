<?php
	$idCategoria = $_GET["idCategoria"];
	
	include '../complemento/conexao.php';
		
	$comandoSQL = "SELECT * FROM categoria WHERE idCategoria = '$idCategoria'";
	$rs = mysqli_query($conexao, $comandoSQL) or
		die("Erro no MYSQL: " . mysqli_error($conexao));
	$dados=mysqli_fetch_array($rs,1);
	
	$categoria = $dados['categoria'];
    $linha = $dados['linha'];

?>