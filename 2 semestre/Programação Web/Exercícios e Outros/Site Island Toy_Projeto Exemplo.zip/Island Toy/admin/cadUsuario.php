<?php
	$idUsuario = $_POST["idUsuario"];
	$nomeUsuario = $_POST["nome"];
	$login = $_POST["login"];
	$senha = $_POST["senha"];
	
	include '../complemento/conexao.php';
		
	$comandoSQL = "INSERT INTO usuario VALUES ('$idUsuario','$nomeUsuario','$login', '$senha')";
	$rs = mysqli_query($conexao, $comandoSQL) or
		die("Erro no MYSQL: " . mysqli_error($conexao));
	
	print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=telaUsuario.php'>";
?>