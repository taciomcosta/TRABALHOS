<?php
	include '../complemento/conexao.php';
	$comandoSQL = 'SELECT categoria FROM categoria ORDER BY categoria';
	$rs = mysqli_query($conexao,$comandoSQL) or
		die("Erro no MYSQL: " . mysqli_error($conexao));
	$linhas = mysqli_num_rows($rs);
		echo '<select name="categoria"/>';
			if($linhas > 0){
				for($n=0;$n<$linhas;$n++){
					$dados=mysqli_fetch_array($rs,1);
					echo '<option>' . $dados['Categoria'].'</option>';
				}
			}
		echo '</select>';
				
?>