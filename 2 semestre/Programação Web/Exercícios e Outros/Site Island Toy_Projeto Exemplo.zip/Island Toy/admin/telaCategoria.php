<?php session_start();?>
<html>
	<head>
		<title>Controle de Categoria</title>
	        <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
			<!--<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />-->
                <link rel="shortcut icon" href="favicon.ico">
                <link rel="stylesheet" href="../css/style.css">
        </head>
	
	<body>
              <?php
                  if (isset($_SESSION["id"]) == 0){
                     header("location: ../index.php");
                   } 
                  ?> 
        <div class="topo">
            <?php
	            include('head.php');
            ?>
        </div>

        <div class="menutop">
        </div>
            <div class="conteudo">
				<div class="colunamenu">
					<div id ="menu" >
						<ul>
							<li><h2>Menu</h2> </li>
                                                        
							<li><a href="telaProduto.php">Controle de Produto</a> </li>
							<li><a href="telaUsuario.php">Controle de Usuario</a> </li>
                                                        <li><a href="index.php">Voltar </a> </li>
						</ul>
					</div>
				</div>
				<div class="center"> 
                    <h2>Categorias</h2>
                    <br/>
					<table border="1" cellspacing="0"> 
						<form action="formCategoria.php" method="post" enctype="multipart/form-data">
                            <tr>                                                             
			<td  align="left" colspan="5"><input type="submit" name="Cadastrar" value="Cadastrar Nova Categoria"/>
                            </tr>
							<tr>
                                                               
								<th>ID</th>
								<th>Categoria</th>
								<th>Linha</th>
                                                                <th>Editar</th>
                                                                <th>Excluir</th>
							</tr>


<?php
    include '../complemento/conexao.php';
	
	$SQL = "  SELECT *";
	$SQL .= " FROM categoria";
	$SQL .= " ORDER BY idCategoria";
	
	$res = mysqli_query($conexao, $SQL) or 
        die("Erro na consulta");
    $linha = mysqli_num_rows($res);

	for($n=0;$n<$linha;$n++){
        echo "<tr>";
			$dados=mysqli_fetch_array($res,1);
            $id = $dados['idCategoria'];
			$categoria = $dados['categoria'];
            $linhaProduto = $dados['linha'];

            echo "<td>" . $id . "</td>";
            echo "<td>" . $categoria . "</td>";
            echo "<td>" . $linhaProduto . "</td>";

            echo "<td><a href='formEdtCategoria.php?idCategoria= $id'>Editar</a></td>";
            echo "<td><a href='delCategoria.php?idCategoria= $id'>Excluir</a></td>";
                 
		echo "</tr>";
}?>						
                                   </form>
                                      </table>   
				</div>
				<div class="footer">
					
					<?php
						include('../complemento/footer.php');
					?>
				</div>
			</div>
	</body>

</html>
