<?php

	$idProduto = $_POST["idProduto"];
	$nome = $_POST["nome"];
	$descricao = $_POST["descricao"];
	
	if (isset($_POST["destaque"]))
		$destaque = $_POST["destaque"];
	else
		$destaque = 'N';	
	
	$categoria = $_POST["categoria"];
	include '../complemento/conexao.php';
	$comandoSQL = "SELECT idCategoria FROM categoria WHERE categoria ='$categoria'";
	 $rs = mysqli_query($conexao, $comandoSQL) or
		die("Erro no MYSQL: " . mysqli_error($conexao));
		
	$dados=mysqli_fetch_array($rs,1);
	$idCategoria = $dados['idCategoria'];
	
	
	$sexo = $_POST["sexo"];
	$faixaEtaria = $_POST["faixaEtaria"];
	$preco = $_POST["preco"];
	$desconto = $_POST["desconto"];
	$parcela = $_POST["parcela"];
	$fabricante = $_POST["fabricante"];
	$qdadeEstoque = $_POST["qdadeEstoque"];
	
//Variaveis para as fotos
	$tmpArqFoto = $_FILES['fotoLista']['tmp_name'];
	$foto = $_FILES['fotoLista']['name'];
	$tmpArqFotoD = $_FILES['fotoDescricao']['tmp_name'];
	$fotoD= $_FILES['fotoDescricao']['name'];
	
// Iremos mover os arquivos para pastas diferentes 
	if(isset($_FILES['fotoLista'])) {
 		if($_FILES['fotoLista']['tmp_name'])
 		{
			// Fazemos isto para verificar se a foto foi enviada. Em caso positivo, moveremos o arquivo. 
			$posicao = strrpos($foto , ".");
			if(!$posicao)
				die("Informe um arquivo de imagem válido");

			$extensao= substr ( $foto , $posicao );
			$nomeArquivo = $idProduto . $extensao;

			if( move_uploaded_file($tmpArqFoto , "../img/" . $nomeArquivo )) {
				echo 'Foto foi movida para a pasta de fotos, com sucesso <br>';
			}
			else 
			{
				echo(  '1-Ocorreu algum erro ao tentar mover a foto para sua pasta.<br>' . mysqli_error($conexao)); 
				echo "Arquivo temporário: $tmpArqFoto <br>";
				echo "Erro: " . $_FILES['fotoLista']['error'] . "<br>";
				die(" Nome do arquivo: $foto <br>");
			}
 		}
	}	 
	if(isset($_FILES['fotoDescricao'])) { 
            if($_FILES['fotoDescricao']['tmp_name']){

			$posicao = strrpos($foto , ".");
			if(!$posicao)
				die("Informe um arquivo de imagem válido");

			$extensao= substr ( $foto , $posicao );
			$nomeArquivo2 = $idProduto. "G" . $extensao;

		if( move_uploaded_file($tmpArqFotoD , "../img/" . $nomeArquivo2)) {
			echo 'A foto foi movido para a pasta de fotos, com sucesso <br>';
		}		
		else {
			echo 'Ocorreu algum erro ao tentar mover a foto da Descrição para sua pasta.<br>'; 
   	        } 
             }
        }
	
	include '../complemento/conexao.php';
		
	$comandoSQL = "INSERT INTO produto VALUES ('$idProduto','$nome','$descricao','$destaque','$idCategoria','$sexo','$faixaEtaria','$preco','$desconto','$parcela','$fabricante','$qdadeEstoque')";
	$rs = mysqli_query($conexao, $comandoSQL) or
		die("Erro no MYSQL: " . mysqli_error($conexao));
		
	print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=telaProduto.php'>";		
?>