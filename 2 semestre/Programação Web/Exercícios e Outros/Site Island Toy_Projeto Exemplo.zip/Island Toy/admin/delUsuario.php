<?php
	include '../complemento/conexao.php';
	
	
                $id = $_GET['idUsuario'];
		$comandoSQL = "DELETE FROM usuario WHERE id = '$id'";
		$resultado = mysqli_query($conexao, $comandoSQL) or 
			die("Erro na consulta");
	
        print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=telaUsuario.php'>";
?>