<?php
	include '../complemento/conexao.php';
	
                $idProduto = trim($_GET['idProduto']);
		$comandoSQL = "DELETE FROM produto WHERE idProdutos = '$idProduto'";
		$resultado = mysqli_query($conexao, $comandoSQL) or 
			die("Erro na consulta");

                print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=telaProduto.php'>";
?>