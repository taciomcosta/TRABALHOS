<?php session_start();?>
<html>
	<head>
		<title>Controle de Produto</title>
	        <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
			<!--<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />-->
                <link rel="shortcut icon" href="favicon.ico">
                <link rel="stylesheet" href="../css/style.css">
        </head>
	
	<body>
              <?php
                  if (isset($_SESSION["id"]) == 0){
                     header("location: ../index.php");
                   } 
                  ?> 
        <div class="topo">
            <?php
	            include('head.php');
            ?>
        </div>

        <div class="menutop">
        </div>
            <div class="conteudo">
				<div class="colunamenu">
					<div id ="menu" >
						<ul>
							<li><h2>Menu</h2> </li>
                                                        
							<li><a href="telaCategoria.php">Controle de Categoria</a> </li>
							<li><a href="telaUsuario.php">Controle de Usuario</a> </li>
                                                        <li><a href="index.php">Voltar </a> </li>
						</ul>
					</div>
				</div>
				<div class="center"> 
                    <h2>Produtos</h2>
                    <br/>
					<table border="1" cellspacing="0"> 
						<form action="formProduto.php" method="post" enctype="multipart/form-data">
                            <tr>                                                             
			<td  align="left" colspan="14"><input type="submit" name="Cadastrar" value="Cadastrar Novo Produto"/>
                            </tr>
							<tr>
                                                        
								<th>ID</th>
								<th>Nome</th>
								<th>Descricao</th>
								<th>Destaque</th>
								<th>Categoria</th>
								<th>Sexo</th>
								<th>Faixa Etaria</th>
								<th>Preco</th>
								<th>Desconto</th>
								<th>Max Parcela</th>
								<th>Fabricante</th>
								<th>Estoque</th>
                                                                <th>Editar</th>
                                                                <th>Excluir</th>
							</tr>


<?php
    include '../complemento/conexao.php';
	
	$SQL = "  SELECT *";
	$SQL .= " FROM produto";
	$SQL .= " ORDER BY idProdutos";
	
	$res = mysqli_query($conexao, $SQL) or 
        die("Erro na consulta");
    $linha = mysqli_num_rows($res);

	for($n=0;$n<$linha;$n++){
        echo "<tr>";
			$dados=mysqli_fetch_array($res,1);
            $id = $dados['idProdutos'];
			$nome = $dados['nome'];
            $descricao = $dados[ 'descricao'];
            $destaque = $dados[ 'destaque'];
            $categoria = $dados[ 'idCategoria'];
            $sexo = $dados[ 'sexo'];
            $faixaEtaria = $dados[ 'faixaEtaria'];
		    $preco = $dados['preco'];
            $desconto = $dados['desconto'];
            $maxParcela = $dados['maxParcelas'];
            $fabricante = $dados['fabricante'];
            $estoque = $dados['estoque'];


            echo "<td>" . $id . "</td>";
            echo "<td>" . $nome . "</td>";
		    echo "<td>" . $descricao . "</td>";
			echo "<td>" . $destaque . "</td>";
			echo "<td>" . $categoria . "</td>";
			echo "<td>" . $sexo . "</td>";
			echo "<td>" . $faixaEtaria . "</td>";
			echo "<td>" . $preco . "</td>";
			echo "<td>" . $desconto . "</td>";
			echo "<td>" . $maxParcela . "</td>";
			echo "<td>" . $fabricante . "</td>";
			echo "<td>" . $estoque . "</td>";

                        echo "<td><a href='formEdtProduto.php?idProduto= $id'>Editar</a></td>";
                        echo "<td><a href='delProduto.php?idProduto= $id'>Excluir</a></td>";
                 
		echo "</tr>";
}?>						
                                   </form>
                                      </table>   
				</div>
				<div class="footer">
					
					<?php
						include('../complemento/footer.php');
					?>
				</div>
			</div>
	</body>

</html>
