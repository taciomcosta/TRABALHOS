<?php session_start();?>
<html>
	<head>
		<title>Cadastro de Categoria</title>
                <meta http-equiv="Content-Type" content="text/html; charset=ISO8859-1" />
                <link rel="shortcut icon" href="favicon.ico">
                <link rel="stylesheet" href="../css/style.css">
	</head>
	
	<body>
              <?php
                  if (isset($_SESSION["id"]) == 0){
                     header("location: ../index.php");
                   } 
                  ?> 
             <div class="topo">
             <?php
	         include('head.php');
             ?>
             </div>

             <div class="menutop">
             </div>
             <div class="conteudo">
		<div class="colunamenu">
		    <div id ="menu" >
			<ul>
			    <li><h2>Menu</h2> </li>
				<li><a href="telaProduto.php">Controle de Produtos</a> </li>
				<li><a href="telaUsuario.php">Controle de Usuario</a> </li>
                                <li><a href="index.php">Voltar </a> </li>
			</ul>
		     </div>
		</div>
		
                <div class="center"> 
		<h1>Cadastro de Categoria</h1>
		<br>
		<table border="0">
		<form action="cadCategoria.php" method="post" enctype="multipart/form-data">
			<tr>
				<td>ID da Categoria:
				<td>
					<?php $tabela = "categoria";
					include 'funcUltimoId.php'?>
					<input type="text" name="idCategoria" readonly = "readonly" value = '<?php echo $idNovo; ?>'/>
			</tr>
			
			<tr>
				<td>Nome da Categoria:
				<td><input type="text" name="nome"/>
			</tr>
			
			<tr>
				<td>Linha:
				<td><select name="linha"/>
					
					 <option value="">Selecione</option>

					<option>Meninos</option>
					<option>Meninas</option>
					<option>Todos</option>
					
				</td>
			</tr>
			
				<td  colspan="2" align="center"><input type="submit" name="salvar" value="Salvar"/>
			</tr>
		</form>
		</table>

                </div>
		     <div class="footer">
			
			<?php
			      include('../complemento/footer.php');
			?>
		     </div>
	        </div>
	</body>

</html>
