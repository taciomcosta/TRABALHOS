<?php session_start();?>
<html>
	<head>
		<title>Controle de Usuarios</title>
	        <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
			<!--<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />-->
                <link rel="shortcut icon" href="favicon.ico">
                <link rel="stylesheet" href="../css/style.css">
        </head>
	
	<body>
              <?php
                  if (isset($_SESSION["id"]) == 0){
                     header("location: ../index.php");
                   } 
                  ?>  
        <div class="topo">
            <?php
	            include('head.php');
            ?>
        </div>

        <div class="menutop">
        </div>
            <div class="conteudo">
				<div class="colunamenu">
					<div id ="menu" >
						<ul>
							<li><h2>Menu</h2> </li>
                                                        
							<li><a href="telaProduto.php">Controle de Produto</a> </li>
							<li><a href="telaCategoria.php">Controle de Categoria</a> </li>
                                                        <li><a href="index.php">Voltar </a> </li>
						</ul>
					</div>
				</div>
				<div class="center"> 
                    <h2>Usuarios</h2>
                    <br/>
					<table border="1" cellspacing="0"> 
						<form action="formUsuario.php" method="post" enctype="multipart/form-data">
                            <tr>                                                             
			<td  align="left" colspan="6"><input type="submit" name="Cadastrar" value="Cadastrar Novo Usuario"/>
                            </tr>
							<tr>
                            
								<th>ID</th>
								<th>Nome</th>
								<th>Log in</th>
                                                                <th>Senha</th>
                                                                <th>Editar</th>
                                                                <th>Excluir</th>
							</tr>


<?php
    include '../complemento/conexao.php';
	
	$SQL = "  SELECT *";
	$SQL .= " FROM usuario";
	$SQL .= " ORDER BY id";
	
	$res = mysqli_query($conexao, $SQL) or 
        die("Erro na consulta");
    $linha = mysqli_num_rows($res);

	for($n=0;$n<$linha;$n++){
        echo "<tr>";
			$dados=mysqli_fetch_array($res,1);
            $id = $dados['id'];
			$nome = $dados['nome'];
			$login = $dados['login'];
            $senha = $dados[ 'senha'];

       
            echo "<td>" . $id . "</td>";
            echo "<td>" . $nome . "</td>";
            echo "<td>" . $login . "</td>";
            echo "<td>" . $senha . "</td>";

            echo "<td><a href='formEdtUsuario.php?idUsuario= $id'>Editar</a></td>";
            echo "<td><a href='delUsuario.php?idUsuario= $id'>Excluir</a></td>";
                 
		echo "</tr>";
}?>						
                                   </form>
                                      </table>   
				</div>
				<div class="footer">
				
					<?php
						include('../complemento/footer.php');
					?>
				</div>
			</div>
	</body>

</html>
