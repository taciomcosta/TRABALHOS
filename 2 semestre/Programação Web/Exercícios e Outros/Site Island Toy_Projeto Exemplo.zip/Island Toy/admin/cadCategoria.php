<?php
	$idCategoria = $_POST["idCategoria"];
	$nomeCategoria = $_POST["nome"];
	$linha = $_POST["linha"];
	
	include '../complemento/conexao.php';
		
	$comandoSQL = "INSERT INTO categoria VALUES ('$idCategoria','$nomeCategoria','$linha')";
	$rs = mysqli_query($conexao, comandoSQL) or
		die("Erro no MYSQL: " . mysqli_error($conexao));
	
	print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=telaCategoria.php'>";
?>