<?php session_start();?>
<html>
	<head>
		<title>Editar Usu&aacute;rio</title>
                <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
			<!--<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />-->
                <link rel="shortcut icon" href="favicon.ico">
                <link rel="stylesheet" href="../css/style.css">
	</head>
	
	<body>
              <?php
                  if (isset($_SESSION["id"]) == 0){
                     header("location: ../index.php");
                   } 
                  ?> 

<div class="topo">
            <?php
	            include('head.php');
            ?>
        </div>

        <div class="menutop">
        </div>
            <div class="conteudo">
				<div class="colunamenu">
					<div id ="menu" >
						<ul>
							<li><h2>Menu</h2> </li>
							<li><a href="telaProduto.php">Controle de Produtos</a> </li>
							<li><a href="telaCategoria.php">Controle de Categoria</a> </li>
                                                        <li><a href="index.php">Voltar </a> </li>
						</ul>
					</div>
				</div>
				<div class="center"> 



		<h1>Cadastro de Usu&aacute;rio</h1>
		<br>
		<table border="0">
		<form action="edtUsuario.php" method="post" enctype="multipart/form-data">
			<tr>
				<td>ID do Usuario:
				<td>
					<?php $tabela = "usuario";
                                         include 'consUsuario.php'?>
				<input type="text" name="idUsuario" readonly = "readonly" value = '<?php echo $idUsuario;?>'/>
			</tr>
			
			<tr>
				<td>Nome:
				<td><input type="text" name="nome" value = '<?php echo $nome;?>'/>
			</tr>
			
			<tr>
				<td>Login:
				<td><input type="text" name="login" value = '<?php echo $login;?>'/>
			</tr>
			
			<tr>
				<td>Senha:
				<td><input type="text" name="senha" value = '<?php echo $senha;?>'/>
			</tr>
			
				<td  colspan="2" align="center"><input type="submit" name="editar" value="Editar"/>
			</tr>
		</form>
		</table>


				</div>
				<div class="footer">
				
					<?php
						include('../complemento/footer.php');
					?>
				</div>
			</div>
	</body>

</html>
