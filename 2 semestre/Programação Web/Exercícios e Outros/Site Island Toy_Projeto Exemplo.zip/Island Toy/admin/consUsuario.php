<?php
	$idUsuario = $_GET["idUsuario"];
	
	include '../complemento/conexao.php';
		
	$comandoSQL = "SELECT * FROM usuario WHERE id = '$idUsuario'";
	$rs = mysqli_query($conexao, $comandoSQL) or
		die("Erro no MYSQL: " . mysqli_error($conexao));
		$dados=mysqli_fetch_array($rs,1);
        $nome = $dados['nome'];
		$login = $dados['login'];
        $senha = $dados['senha'];

?>