<?php
	$idProduto = trim($_GET["idProduto"]);
	
	include '../complemento/conexao.php';
		
	$comandoSQL = "SELECT * FROM produto WHERE idProdutos = '$idProduto'";
	$rs = mysqli_query($conexao, $comandoSQL) or
		die("Erro no MYSQL: " . mysqli_error($conexao));
		
		$dados=mysqli_fetch_array($rs,1);
        $nome = $dados['nome'];
        $descricao = $dados['descricao'];
		$destaque = $dados['destaque'];

        $sexo = $dados['sexo'];
		$faixaEtaria = $dados['faixaEtaria'];
		$preco = $dados['preco'];
		$desconto = $dados['desconto'];
		$parcela = $dados['maxParcelas'];
		$fabricante = $dados['fabricante'];
		$qdadeEstoque = $dados['estoque'];

        $idCategoria = $dados['idCategoria'];

	$comandoSQL = "SELECT categoria FROM categoria WHERE idCategoria ='$idCategoria'";
	 $rs = mysqli_query($conexao, $comandoSQL) or
		die("Erro no MYSQL: " . mysqli_error($conexao));
	$dados=mysqli_fetch_array($rs,1);
	$categoria = $dados['categoria'];


?>