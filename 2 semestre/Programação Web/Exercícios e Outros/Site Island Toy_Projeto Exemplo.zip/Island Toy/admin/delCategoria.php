<?php
	include '../complemento/conexao.php';
	
	if(isset($_GET['idCategoria'])){
                $id = $_GET['idCategoria'];
		$comandoSQL = "DELETE FROM categoria WHERE idCategoria = '$id'";
		$resultado = mysqli_query($conexao, $comandoSQL) or 
			die("Erro na consulta");
	}
        print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=telaCategoria.php'>";
?>