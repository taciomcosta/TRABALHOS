<?php session_start();?>
<html>
	<head>
		<title>Editar Categoria</title>
               <meta http-equiv="Content-Type" content="text/html; charset=ISO_8859-1">
			
		
                <link rel="shortcut icon" href="favicon.ico">
                <link rel="stylesheet" href="../css/style.css">
	</head>
	
	<body>
              <?php
                  if (isset($_SESSION["id"]) == 0){
                     header("location: ../index.php");
                   } 
                  ?> 
             <div class="topo">
             <?php
	         include('head.php');
             ?>
             </div>

             <div class="menutop">
             </div>
             <div class="conteudo">
		<div class="colunamenu">
		    <div id ="menu" >
			<ul>
			    <li><h2>Menu</h2> </li>
				<li><a href="telaProduto.php">Controle de Produtos</a> </li>
				<li><a href="telaUsuario.php">Controle de Usuario</a> </li>
                                <li><a href="index.php">Voltar </a> </li>
			</ul>
		     </div>
		</div>
		
                <div class="center"> 
		<h1>Editar Categoria</h1>
		<br>
		<table border="0">
		<form action="edtCategoria.php" method="post" enctype="multipart/form-data">
			<tr>
				<td>ID da Categoria:
				<td>
					<?php $tabela = "categoria";
					include 'consCategoria.php'?>
					<input type="text" name="idCategoria" readonly = "readonly" value = '<?php echo $idCategoria;?>'/>
			</tr>
			
			<tr>
				<td>Nome da Categoria:
				<td><input type="text" name="nome" value = '<?php echo $categoria;?>'/>
			</tr>
			
			<tr>
				<td>Linha: <?php echo $linha;?>
				<td><select name="linha" />
					
					 <option><?php echo $linha;?></option>

					<option>Meninos</option>
					<option>Meninas</option>
					<option>Todos</option>
					
				</td>
			</tr>
			
				<td  colspan="2" align="center"><input type="submit" name="editar" value="Editar"/>
			</tr>
		</form>
		</table>

                </div>
		     <div class="footer">
			
			<?php
			      include('../complemento/footer.php');
			?>
		     </div>
	        </div>
	</body>

</html>
