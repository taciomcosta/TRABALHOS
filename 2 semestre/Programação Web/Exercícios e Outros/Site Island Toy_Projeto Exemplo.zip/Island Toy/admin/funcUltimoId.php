<?php
	include '../complemento/conexao.php';
	
	if($tabela == "produto"){
	$comandoSQL = "SELECT idProdutos FROM produto ORDER BY idProdutos DESC";
	$rs = mysqli_query($conexao,$comandoSQL) or
		die("Erro no MYSQL: " . mysqli_error($conexao));
		$dados=mysqli_fetch_array($rs,1);
		$idNovo = trim(($dados['idProdutos']+1));
	}
	else if($tabela=="categoria"){
		$comandoSQL = "SELECT idCategoria FROM categoria ORDER BY idCategoria DESC";
		$rs = mysqli_query($conexao,$comandoSQL) or
		die("Erro no MYSQL: " . mysqli_error($conexao));
		$dados=mysqli_fetch_array($res,1);
		$idNovo = trim(($dados['idCategoria']));
		
	}
	
	else if($tabela == "usuario"){
		$comandoSQL = "SELECT id FROM usuario ORDER BY id DESC";
		$rs = mysqli_query($conexao,$comandoSQL) or
		die("Erro no MYSQL: " . mysqli_error($conexao));
		$dados=mysqli_fetch_array($res,1);
		$idNovo = trim(($dados['id']+1));
	}
?>