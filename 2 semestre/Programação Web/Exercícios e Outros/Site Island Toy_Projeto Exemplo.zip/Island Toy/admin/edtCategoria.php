<?php
	$idCategoria = $_POST["idCategoria"];
	$nomeCategoria = $_POST["nome"];
	$linha = $_POST["linha"];
	
	include '../complemento/conexao.php';
		
	$comandoSQL = "UPDATE categoria SET categoria = '$nomeCategoria', linha = '$linha' WHERE idCategoria = '$idCategoria'";
	$rs = mysqli_query($conexao, $comandoSQL) or
		die("Erro no MYSQL: " . mysqli_error($conexao));
	
        print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=telaCategoria.php'>";
?>