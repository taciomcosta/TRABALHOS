<?php session_start();?>

<html>
    <head>
        <title>Area Administrativa</title>
        <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
			<!--<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />-->
        <link rel="shortcut icon" href="favicon.ico">
        <link rel="stylesheet" href="../css/style.css">
     </head>          
     <body>
      <?php
         if (isset($_SESSION["id"]) == 0){
            header("location: ../index.php");
             
         } 
      ?>  
            <div class="topo">
                  <?php
	                include('head.php');
                  ?>
            </div>

            <div class="menutop">
            </div>

            <div class="conteudo">
				<div class="colunamenu">
					<div id ="menu" >
						<ul>
							<li><h3>�rea Administrativa</h3> </li>
							<li><a href="telaProduto.php">Produto</a> </li>
							<li><a href="telaCategoria.php">Categoria</a> </li>
							<li><a href="telaUsuario.php">Usuario</a> </li>
						</ul>
					</div>
				</div>
				<div class="center">  
                              
				      <?php

                                         echo "<h1>" . $_SESSION['nome'] . " Bem vindo a �rea Administrativa</h1>"; 
                                          include '../complemento/conexao.php';
	
	                                  $SQL = "  SELECT *";
	                                  $SQL .= " FROM categoria";
	
	                                 $res = mysqli_query($conexao, $SQL) or 
                                             die("Erro na consulta");
                                         $linCategoria = mysqli_num_rows($res);

                                         $SQL = "  SELECT *";
	                                  $SQL .= " FROM produto";
	
	                                 $res = mysqli_query($conexao,$SQL) or 
                                             die("Erro na consulta");
                                         $linProduto = mysqli_num_rows($res);

	                              
                                         $SQL = "  SELECT *";
	                                  $SQL .= " FROM usuario";
	
	                                 $res = mysqli_query($conexao,$SQL) or 
                                             die("Erro na consulta");
                                         $linUsuario = mysqli_num_rows($res);

                                     echo "<table border='1' cellspacing='0'>"; 
                                         
                                          echo "<tr>";
                                               echo "<th>Tabela</th>";
                                               echo "<th>Qdade Registros</th>";
                                          echo "</tr>";
                                          echo "<tr>";
                                               echo "<td>Categoria</td>";
                                               echo "<td><center>" . $linCategoria . "<center></td>";
                                          echo "</tr>";
                                          echo "<tr>";
                                               echo "<td>Produto</td>";
                                               echo "<td><center>" . $linProduto . "<center></td>";
                                          echo "</tr>";
                                          echo "<tr>";
                                               echo "<td>Usuario</td>";
                                               echo "<td><center>" . $linUsuario . "</center></td>";
                                          echo "</tr>";
                                       echo "</table>";
                                       ?>
				</div>
				<div class="footer">
					
					<?php
						include('../complemento/footer.php');
					?>
				</div>
			</div>
		</body>
</html>