<?php session_start();?>
<html>
	<head>
		<title>Editar Produto</title>
                <meta http-equiv="Content-Type" content="text/html; charset=ISO_8859-1">
			<!--<meta http-equiv="Content-Type" content="text/html; charset=ISO_8859-1" />-->
                <link rel="shortcut icon" href="favicon.ico">
                <link rel="stylesheet" href="../css/style.css">
	</head>
	
	<body>
              <?php
                  if (isset($_SESSION["id"]) == 0){
                     header("location: ../index.php");
                   } 
                  ?> 
        <div class="topo">
            <?php
	            include('head.php');
            ?>
        </div>

        <div class="menutop">
        </div>
            <div class="conteudo">
				<div class="colunamenu">
					<div id ="menu" >
						<ul>
							<li><h2>Menu</h2> </li>
							<li><a href="telaCategoria.php">Controle de Categoria</a> </li>
							<li><a href="telaUsuario.php">Controle de Usuario</a> </li>
                                                        <li><a href="index.php">Voltar </a> </li>
						</ul>
					</div>
				</div>
				<div class="center"> 
                                     <h1>Editar Produto</h1>
		<br>
		<table border="0">
                
		      <form action="edtProduto.php" method="post" enctype="multipart/form-data">
			<tr>
				<td>ID do Produto:
				<td>
					<?php $tabela = "produto";
					include 'consProduto.php'?>
					<input type='text' style="font-weight:bold" readonly name="idProduto" maxlength='5' size='25' value='<?php echo $idProduto; ?>'/>
                                        
			</tr>
			
			<tr>
				<td>Nome:
				<td><input type="text" name="nome" size="40"value = '<?php echo $nome;?>'/>
			</tr>
			
			<tr>
				<td>Descri&ccedil;&atilde;o:
				<td><input type="text" name="descricao" size="40" value = '<?php echo $descricao;?>'/>
			</tr>
			
			<tr>
				<td>Destaque:
                                <?php if($destaque =='S'){;?>
				<td><input type="checkbox" name="destaque" value = 'S' checked />Produto em Destaque
                        <?php } else{ ?>
                                <td><input type="checkbox" name="destaque" value = 'S' />Produto em Destaque
                        <?php } ?>
			</tr>
			
			<tr>
				<td>Categoria:
				<td>
					 
                                     <?php
	                                 include '../complemento/conexao.php';
	                                 $comandoSQL = 'SELECT categoria FROM categoria ORDER BY categoria';
	                                     $rs = mysqli_query($conexao, $comandoSQL) or
		                         die("Erro no MYSQL: " . mysqli_error($conexao));
	                                 $linhas = mysqli_num_rows($rs);
		                         echo '<select name="categoria"/>';
                                        ?>
                                         //Busca qual a op��o que est� cadastrada
                                          <option><?php echo $categoria;?></option>
                                        <?php
			                     if($linhas > 0){
				                for($n=0;$n<$linhas;$n++){
									$dados=mysqli_fetch_array($rs,1);
					          echo '<option>' . $dados['categoria'].'</option>';
				                }
			                      }
		                               echo '</select>';
				
                                         ?>

				</td>
			</tr>
			
			<tr>
				<td>Sexo:
				<td><input type="radio" name="sexo" value="M" checked>Masculino  
					<input type="radio" name="sexo" value="F">Feminino  
					<input type="radio" name="sexo" value="A">Ambos
	
				</td>
			</tr>
			
			<tr>
				<td>Faixa Etaria:
				<td><input type="text" name="faixaEtaria" size="40" value = '<?php echo $faixaEtaria;?>'/>
			</tr>			
			<tr>
				<td>Pre&ccedil;o:
				<td><input type="text" name="preco" size="40" value = '<?php echo $preco;?>'/>
			</tr>
			
			<tr>
				<td>Desconto:
				<td><input type="text" name="desconto" size="40" value = '<?php echo $desconto;?>'/>
			</tr>
			
			<tr>
				<td>Parcela Maxima:
				<td><input type="text" name="parcela" size="40" value = '<?php echo $parcela;?>'/>
			</tr>
			
			<tr>
				<td>Fabricante:
				<td><input type="text" name="fabricante" size="40" value = '<?php echo $fabricante;?>'/>
			</tr>
			
			<tr>
				<td>Qdade Estoque:
				<td><input type="text" name="qdadeEstoque" size="40" value = '<?php echo $qdadeEstoque;?>'/>
			</tr>
			
			<tr>
				<td>Foto da Lista:
				<td><input type="file" name="fotoLista"/>
			</tr>
			
			<tr>
				<td>Foto da Descri&ccedil;&atilde;o:
				<td><input type="file" name="fotoDescricao"/>
			</tr>
			
			<tr>  
				<td  align="center"><input type="submit" name="Alterar" value="Alterar"/>
				<td> <input type="reset" name="limpar" value="Limpar Dados"/>
			
			</tr>
			
		</form>
		</table>

				</div>
				<div class="footer">
					
					<?php
						include('../complemento/footer.php');
					?>
				</div>
			</div>
	</body>

</html>
