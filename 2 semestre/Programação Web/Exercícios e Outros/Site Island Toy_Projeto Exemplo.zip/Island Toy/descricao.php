<html>
<head>
 <title>Descri��o do Produto</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<!--<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />-->
 <link rel="shortcut icon" href="favicon.ico">
            <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="topo" id="topodescricao">
<?php
	include('complemento/head.php');
?>
</div>

<div class="todomenutop">
<?php
	include('complemento/menutop.php');
?>
</div>

<div class="conteudo">
	<div class="colunamenu">
	<?php
		include('complemento/menu.php');
	?>
	</div>

	<div class="center">
    <?php
		$codigo = $_GET['produtos'];
		$SQL = "  SELECT * ";
		$SQL .= " FROM produto where idProdutos='$codigo' ";
		$SQL .= " ORDER BY idProdutos ";
		$res = mysqli_query($conexao, $SQL) or die("Erro na consulta");
		$produto = mysqli_fetch_assoc($res);
		
		    $nome = $produto['nome'] ;
		    $valor = $produto['preco'] ;
                    $desconto = $produto['desconto'];
                    $parcela = $produto['maxParcelas'];
			//$valor = number_format($valor, 2, ',', '.'); 
			$descricao = $produto['descricao'] ;     
		    //echo "img/".$codigo.".jpg";
			
                 ?>
                 
        <div class=conteudo>
   			<div class=imagem_descricao>
        		<?php echo " <img src=\" img/".$codigo."G.jpg \" width=\"100%\" height=\"100%\" />"; ?>
			</div>
			<div class=descricao_resumo>
        		<?php 
                                echo "<br><center>C�d. Produto: " . $codigo . "</center>";
				echo "<center>" . $nome . "</center>";
                                if($desconto==0){
				   echo "<center>R$ ".$valor."</center>";
                                } else{
                                     echo "<center>R$ ".$valor."</center>";
                                     echo "<center>Desconto de " . $desconto . "%</center>";
                                     $valor -= ($valor * ($desconto / 100));
                                     $valor = number_format($valor, 2, ',', '.');
                                     echo "<center>Por apenas: " . "R$ " . $valor . "</center>";
                                }
                                if ($parcela>1){
                                    echo "<center>em at� " . $parcela . " vezes sem Juros</center>";
                                }
				?>
			</div>
			<div class=descricao_produto>
        	<?php 	echo "<center>".$descricao."</center>"; ?>
			</div>
        </div>   
		
       <?php // }?>  
	</div>
</div>
<div class="footer">

<?php
	include('complemento/footer.php');
?>
</div>
</body>
</html>
