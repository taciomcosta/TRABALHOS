<?php
    //Obtendo o parâmetro código do produto e  se está em destaque
	$codigo = $_GET["cod"];
	$destaque = $_GET["destaque"];
    
    //Conexão com o Servidor de Banco de Dados
    //Selecionando o Banco de Dados
	include '../complemento/conexao.php';
    
	if (($destaque=='S') || ($destaque=='N')){
		//Atualiza o campo destaque
		$rs = mysqli_query($conexao, , "UPDATE produto SET destaque= '$destaque' WHERE idProdutos='$codigo'");
                die("Erro.");
    }
	Else{
		//Efetuando a consulta à dados com base no código do produto 
		$rs = mysqli_query($conexao, , "SELECT idProdutos, destaque FROM produto WHERE idProdutos='$codigo'");
	}
	
	
    //Verifica se há registro
    if (mysqli_affected_rows() > 0) {
        //obtém a linha de dado em forma de array
        $dado = mysqli_fetch_assoc($rs);
    
        //Criando uma estrutura "JSON" a partir dos dados do array "$dado".
        //A constante "JSON_PRETTY_PRINT" define a formatação visual do "JSON".
        $json = json_encode($dado);
        
        //Definindo o cabeçalho de resposta 
        header('content-type: application/json; charset=utf-8');

        //Exibindo o resultado
        echo $json;
    }
	mysqli_close($conexao);
?>