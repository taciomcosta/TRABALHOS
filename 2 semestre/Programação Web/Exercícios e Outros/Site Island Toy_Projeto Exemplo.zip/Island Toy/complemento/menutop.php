	<div class="menutop" >
		<ul >
 			<li><a href="index.php">Destaque</a></li>
 			<li><a href="telaMenina.php">Meninas</a></li>
 			<li><a href="telaMenino.php">Meninos</a></li>
 			<li><a href="poridade.php">Por Idade</a></li>
		</ul>
	</div>
	<div class="Pesquisa">
		<form method="get" action="pesquisa.php">
			<input type="search" name="pesq" />
			<input type="submit" name="pesquisar" value="Pesquisar"/>
		</form>
	</div>
