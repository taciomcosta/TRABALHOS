<div id="menu" >
<ul >
	<?php
            echo "<h3>Filtrar por:</h3>";

		$SQL = "  SELECT *";
		$SQL .= " FROM produto ";
		$SQL .= " GROUP BY faixaEtaria ";
		$res = mysqli_query($conexao, $SQL) or die("Erro na consulta");
		//for($n=0;$n<12;$n++){
			while ($faixaEtaria1 = mysqli_fetch_assoc($res)) {
				
				 if ($faixaEtaria1['faixaEtaria'] ==0){
					$faixaEtaria ='todos'; 
				 }else{
				 $faixaEtaria=$faixaEtaria1['faixaEtaria'];
				 }
			echo "<li><a href='poridade.php?faixaEtaria=".$faixaEtaria."' > ".$faixaEtaria." anos</a></li>";
           // $faixaEtaria = mysql_result($res,$n,'faixaEtaria');
			//if ($faixaEtaria==0){
			//	$faixaEtaria ='todos';
			//}
			//echo "<li><a href='poridade.php?faixaEtaria=".$faixaEtaria."' > ".$faixaEtaria." ano</a></li>";
			
		}
	?>  

</ul>  
</div>