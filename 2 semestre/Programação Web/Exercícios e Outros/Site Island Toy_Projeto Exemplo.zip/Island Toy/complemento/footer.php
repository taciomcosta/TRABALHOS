<div class="rodape">
	<p>Copyright� 2014 - 2015, <span class="c_preto">Allex Christino e Mauricio Toshio</span> - Projeto Cat�logo IslandToy referente as Mat�rias: Aplica��es para Internet e Programa��o Web utilizando HTML, CSS, PHP e MySQL.</p>
	<p><span class="c_preto"><strong>Advert�ncia</strong></span>: Este Site foi constru�do para fins did�ticos. Dados t�cnicos, imagens, textos e refer�ncias de ordens diversas foram utilizados apenas para o objetivo de obten��o de nota. As informa��es aqui exibidas n�o refletem, em nenhum momento, a realidade.</p>
	<p>Esse Projeto Did�tico n�o possui qualquer conota��o comercial, para quaisquer outros fins que n�o ao do projeto em si.</p>
	<p>Este projeto simula um cat�logo de Com�rcio Eletr�nico. N�o � poss�vel simular uma compra pela Internet. <span class="c_preto"><strong> Nada lhe ser� cobrado e nada lhe ser� entregue</strong></span>.
</div>
