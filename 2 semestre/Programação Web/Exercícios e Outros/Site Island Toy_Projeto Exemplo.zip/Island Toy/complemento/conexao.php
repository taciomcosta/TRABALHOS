<?php
     $conexao = mysqli_connect('localhost','root','') 
           or die("Não foi possível connectar-se ao Servidor MySQL");

     $db = mysqli_select_db($conexao,'islandtoy') 
           or die("Erro ao selecionar o Banco de Dados:". mysqli_error($conexao));
?>