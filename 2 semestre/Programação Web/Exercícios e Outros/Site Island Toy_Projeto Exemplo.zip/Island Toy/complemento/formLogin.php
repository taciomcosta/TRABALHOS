<form action = "complemento/funcLogin.php" method="post">
        <br>
        <legend>
    	    <label>&nbsp;&nbsp;&nbsp;Usuario&nbsp;
	        <input type="text" name="login" id="login" />
            </label><br><br>
            <label>&nbsp;&nbsp;&nbsp;Senha:&nbsp;&nbsp;&nbsp;
                <input type="password" name="senha" id="senha"/>
            </label>
        </legend>
        <br>&nbsp;&nbsp;&nbsp;
        <input type="submit" name"logar" id="logar" />
        <!--&nbsp;&nbsp;<a href="" >esqueceu a senha?</a><br>-->
    </form> 