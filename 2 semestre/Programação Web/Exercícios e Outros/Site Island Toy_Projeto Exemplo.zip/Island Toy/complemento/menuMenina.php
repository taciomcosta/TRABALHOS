<div id="menu" >
<ul >
	<?php
             echo "<h3>Filtrar por:</h3>";

		$SQL = "  SELECT *";
		$SQL .= " FROM categoria where (linha LIKE 'Meninas') or (linha LIKE 'Todos')";
		$SQL .= " ORDER BY categoria ";
		$res = mysqli_query($conexao, $SQL) or die("Erro na consulta");
		
		//for($n=0;$n<12;$n++){
		while ($categoria1 = mysqli_fetch_assoc($res)) {
            $categoria = $categoria1['categoria'];
			$idCategoria = $categoria1['idCategoria'];
			echo "<li><a href='telaMenina.php?categoria=".$idCategoria."' >".$categoria."</a></li>";
			
		}
	?>  

</ul>  
</div>