<div id="menu" >
<h3>Filtrar por:</h3>

<ul >
 <li><a href="index.php">Destaque</a></li>
 <li><a href="telaMenina.php">Meninas</a></li>
 <li><a href="telaMenino.php">Meninos</a></li>
 <li><a href="poridade.php">Por Idade</a></li>
</ul> 
</div>