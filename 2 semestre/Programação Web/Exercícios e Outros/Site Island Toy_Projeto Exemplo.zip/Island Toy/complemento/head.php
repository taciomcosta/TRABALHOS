<?php session_start(); ?>

            <?php
                 include 'conexao.php';
            ?>
            <div class="logo">
	          <a href='../index.php'><img src="img/site/logo.png" width="200px" /></a>
            </div>
            <div class="login">
            <?php
                  if (isset($_SESSION["id"]) == 0){
                        include ('formLogin.php');
                  }elseif(isset($_GET['logoff'])==1){ 
                        session_destroy();

                       header("location: ../index.php");
             
                  }else{ ?>
                        <a href="index.php?logoff=1"><?php echo $_SESSION["nome"]; ?> Click aqui para Sair</a><br>
                        <a href="admin/index.php">Administra��o</a><br>
                    <!--    <a href="http://islandtoy.uni.me/index.php">Pagina Principal</a><br> -->
                  <?php  }?>
            </div>
