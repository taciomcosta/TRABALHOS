<html>
<head>
<title>Island Toy</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!--<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />-->
 <link rel="shortcut icon" href="favicon.ico">
            <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="topo" id="topodestaque">
<?php
	include('complemento/head.php');
?>
</div>

<div class="todomenutop">
<?php
	include('complemento/menutop.php');
?>
</div>

<div class="conteudo">
	<div class="colunamenu">
	<?php
		include('complemento/menu.php');
	?>
	</div>

	<div class="center">
   
    <?php
		$SQL = "  SELECT * ";
		$SQL .= " FROM produto where destaque = 'S' ";
		$SQL .= " ORDER BY idProdutos ";
		$res = mysqli_query($conexao, $SQL) or die("Erro na consulta");
		
		 while ($produto = mysqli_fetch_assoc($res)) {
            $codigo = $produto['idProdutos'] ;
		    $nome = $produto['nome'] ;
		    $valor = $produto['preco'] ;
			$valor = number_format($valor, 2, ',', '.');     
		    //echo "img/".$codigo.".jpg";
                 ?>
		<div class="descricao" >
        	<div class="imagem">
        <?php echo " <a href=\"descricao.php?produtos=".$codigo."\"><img src=\" img/".$codigo.".jpg \" width=\"150px\" height=\"150px\"/></a>"; ?>
            </div>
        	<?php 
			echo "<center>".$nome."</center>";
			echo "<center>R$ ".$valor."</center>";
			?>
        </div>
       <?php }?>  
	</div>
</div>
<div class="footer">

<?php
	include('complemento/footer.php');
?>
</div>
</body>
</html>