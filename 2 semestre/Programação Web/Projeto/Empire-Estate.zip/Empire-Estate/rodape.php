<!-- RODAPÉ -->
        <footer class="section rodape">

            <div class="container">

                <div class="row" >

                <!-- Visite a Empire Estate -->
                    <div class="col-sm-4">
                        <h3>
                            <i class="fa fa-fw fa-location-arrow"></i>Visite a Empire State!</h3>
                        <p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; Rua Cesário Galeno, n° 353,
                            <br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Próximo ao Metrô Carrão - SP
                            <br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Tel: (11) 1111-1111</p>
                    </div>

                    <!-- Logo -->
                    <div class="col-sm-3" id="copyright">
                        <img src="logo/logo2.jpg" alt="Empire State">
                        <p>® Copyright 2016 - Empire State</p>
                    </div>

                    <!-- Redes Sociais -->
                    <div class="col-sm-3" id="redesSociais">
                        <p class="text-info text-right">
                            <br>
                            <br>
                        </p>
                        <div class="row">
                            <div class="col-md-12 hidden-lg hidden-md hidden-sm text-left">
                                <a href="http://www.instagram.com"><i class="fa fa-2x fa-fw fa-instagram text-inverse"></i></a>
                                <a href="http://www.twitter.com"><i class="fa fa-2x fa-fw fa-twitter text-inverse"></i></a>
                                <a href="http://www.facebook.com"><i class="fa fa-2x fa-fw fa-facebook text-inverse"></i></a>
                            </div>
                        </div>
                        <div class="row" >
                            <div class="col-md-12 hidden-xs text-right">
                                <a href="http://www.instagram.com"><i class="fa fa-2x fa-fw fa-instagram text-inverse"></i></a>
                                <a href="http://www.twitter.com"><i class="fa fa-2x fa-fw fa-twitter text-inverse"></i></a>
                                <a href="http://www.facebook.com"><i class="fa fa-2x fa-fw fa-facebook text-inverse"></i></a>
                            </div>
                        </div>
                    </div><!-- Redes Sociais -->

                </div>

            </div>

        </footer>