package exe02;

import java.util.Scanner;

public class Teste {
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		Calculadora c = new Calculadora();
		
		System.out.println("Calculadora\n");
		
		System.out.println("Digite o valor A: ");
		c.setValorA(input.nextDouble());
		
		System.out.println("Digite o valor B: ");
		c.setValorB(input.nextDouble());
		
		System.out.println("\nRESULTADOS");
		System.out.println("Soma: " + c.somar());
		System.out.println("Subtra��o: " + c.subtrair());
		System.out.println("Multiplica��o: " + c.multiplicar());
		System.out.println("Divis�o: " + c.dividir());
		
	}
}
