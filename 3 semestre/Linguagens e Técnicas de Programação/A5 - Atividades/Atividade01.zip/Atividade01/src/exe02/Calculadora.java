package exe02;

public class Calculadora 
{
	//Atributos
	private double valorA;
	private double valorB;
	
	//M�todos
	//setters
	public void setValorA(double valorA)
	{
		this.valorA = valorA;
	}
	
	public void setValorB(double valorB)
	{
		this.valorB = valorB;
	}
	
	//getters
	public double getValorA()
	{
		return this.valorA;
	}
	
	public double getValorB()
	{
		return this.valorB;
	}
	
	//Outros
	public double somar()
	{
		return getValorA() + getValorB();
	}
	
	public double subtrair()
	{
		return getValorA() - getValorB();
	}
	
	public double multiplicar()
	{
		return getValorA() * getValorB();
	}
	
	public double dividir()
	{
		return getValorA() / getValorB();
	}
}
