package exe04;

import java.util.Scanner;

public class Teste 
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		NumeroInteiro n = new NumeroInteiro();
		
		System.out.println("Digite um n�mero: ");
		n.setNum(input.nextInt());
		
		System.out.println("\n� par: " + n.numPar());
		System.out.println("� �mpar: " + n.numImpar());
		System.out.println("� primo: " + n.numPrimo());
		System.out.println(n.getNum() + "! = " + n.fatorial());
		
	}
}
