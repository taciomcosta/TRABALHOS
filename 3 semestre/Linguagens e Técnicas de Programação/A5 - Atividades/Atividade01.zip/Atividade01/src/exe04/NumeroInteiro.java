package exe04;

public class NumeroInteiro 
{
	//Atributos
	private int num;
	
	//M�todos
	//setter e getter
	public void setNum(int num)
	{
		this.num = num;
	}
	
	public int getNum()
	{
		return this.num;
	}
	
	//outros
	public boolean numPar()
	{
		if (this.num%2 == 0)
			return true;
		else
			return false;
	}
	
	public boolean numImpar()
	{
		if (this.num%2 == 1)
			return true;
		else
			return false;
	}
	
	public boolean numPrimo()
	{
		int i, 
		cont = 0;
		
		for (i = 1; i <= this.num; i++) {
			if (this.num%i == 0)
				cont++;
		}
		
		if (cont == 2)
			return true;
		else
			return false;
	}
	
	public long fatorial()
	{
		int i, fat = 1;
		
		for (i = this.num; i > 1; i--) {
			fat *= i;
		}
		
		return fat;
	}
}
