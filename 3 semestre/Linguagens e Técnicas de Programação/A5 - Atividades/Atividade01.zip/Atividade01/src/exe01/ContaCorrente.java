package exe01;

public class ContaCorrente 
{
	//Atributos
	private String nomeCliente;
	private int numConta;
	private int numAgencia;
	private double saldo = 10000;
	
	//M�todos
	//setters
	public void setNomeCliente(String nomeCliente)
	{
		this.nomeCliente = nomeCliente;
	}
	
	public void setNumConta(int numConta)
	{
		this.numConta = numConta;
	}
	
	public void setNumAgencia(int numAgencia)
	{
		this.numAgencia = numAgencia;
	}
	
	//getters
	public String getNomeCliente()
	{
		return this.nomeCliente;
	}
	
	public int getNumConta()
	{
		return this.numConta;
	}
	
	public int getNumAgencia()
	{
		return this.numAgencia;
	}
	
	//construtores
	public ContaCorrente()
	{
		
	}
	
	public ContaCorrente(String nomeCliente, int numConta, int numAgencia)
	{
		setNomeCliente(nomeCliente);
		setNumConta(numConta);
		setNumAgencia(numAgencia);
	}
	
	//outros
	public void depositar(double valor)
	{
		this.saldo += valor;
		this.saldo -= valor*0.007;
	}
	
	public void sacar(double valor)
	{
		this.saldo -= valor + valor*0.03;
	}

	public double obterSaldo()
	{
		return this.saldo;
	}
	
	public void imprimirExtrato()
	{
		System.out.println();
		System.out.println("Nome do Cliente: " + getNomeCliente());
		System.out.println("Conta Corrente: " + getNumConta());
		System.out.println("N�mero da Ag�ncia: " + getNumAgencia());
		System.out.println("Saldo: R$ " + obterSaldo());
	}
	
}
