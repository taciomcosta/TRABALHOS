package exe01;

import java.util.Scanner;

public class TesteContaCorrente 
{
	public static void main(String[] args)
	{
		//vars
		Scanner input = new Scanner(System.in);
		Scanner input1 = new Scanner(System.in);
		String nome; 
		int conta, agencia, 
			opcao = 0;
		double valor;
		
		//CONTA 1
		System.out.println("CONTA 1\n");
		
		System.out.println("Nome do cliente: ");
		nome = input.nextLine();
		
		System.out.println("N�mero da conta: ");
		conta = input.nextInt();
		
		System.out.println("N�mero da ag�ncia: ");
		agencia = input.nextInt();
		
		
		ContaCorrente conta1 = new ContaCorrente(nome, conta, agencia);
		
		//CONTA 2
		ContaCorrente conta2 = new ContaCorrente();
		
		System.out.println("CONTA 2\n");
		
		System.out.println("Nome do cliente: ");
		conta2.setNomeCliente(input1.nextLine());
		
		System.out.println("N�mero da conta: ");
		conta2.setNumConta(input1.nextInt());
		
		System.out.println("N�mero da ag�ncia: ");
		conta2.setNumAgencia(input1.nextInt());
		
		//Login
		while (true) {
			System.out.println("\nLogin\n");
			System.out.println("Num conta: ");
			conta = input1.nextInt();
			
			System.out.println("Num ag�ncia: ");
			agencia = input.nextInt();
			
			if (conta == conta1.getNumConta() && agencia == conta1.getNumAgencia()) {
				System.out.println("Seja bem-vindo, " + conta1.getNomeCliente() + "\n");
			} else if (conta == conta2.getNumConta() && agencia == conta2.getNumAgencia()) {
				System.out.println("Seja bem-vindo, " + conta2.getNomeCliente() + "\n");
			} else {
				System.out.println("Login inv�lido!!!");
			}
			
			//Selecionando a op��o
			while (opcao != 5) {
				System.out.println("\nOp��es: \n");
				System.out.println("1 - Depositar");
				System.out.println("2 - Sacar");
				System.out.println("3 - Obter saldo");
				System.out.println("4 - Imprimir extrato");
				System.out.println("5 - Sair");
				System.out.print("Selecione a op��o desejada: ");
				opcao = input.nextInt();
				
				if (conta == conta1.getNumConta() && agencia == conta1.getNumAgencia()) {
					if (opcao == 1) {
						System.out.print("\nValor: R$");
						valor = input.nextDouble();
						conta1.depositar(valor);
					}
					
					if (opcao == 2) {
						System.out.print("\nValor: R$");
						valor = input.nextDouble();
						conta1.depositar(valor);
					}
					
					if (opcao == 3) {
						System.out.print("\nSaldo: R$" + conta1.obterSaldo());
					}
					
					if (opcao == 4) {
						conta1.imprimirExtrato();
					}
						
				} else {
					if (opcao == 1) {
						System.out.print("\nValor: R$");
						valor = input.nextDouble();
						conta2.depositar(valor);
					}
					
					if (opcao == 2) {
						System.out.print("\nValor: R$");
						valor = input.nextDouble();
						conta2.depositar(valor);
					}
					
					if (opcao == 3) {
						System.out.print("\nSaldo: R$" + conta2.obterSaldo());
					}
					
					if (opcao == 4) {
						conta2.imprimirExtrato();
					}
				}
			}
		}
		
		
	}
}
