package exe03;

public class Teste {
	public static void main(String[] args)
	{
		Triangulo t = new Triangulo(3, 4, 5);
		t.imprimeTipo();
	}
}
