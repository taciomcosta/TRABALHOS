package exe03;

public class Triangulo 
{
	//Atributos
	private int lado1;
	private int lado2;
	private int lado3;
	
	//M�todos
	//construtores
	public Triangulo()
	{
		
	}
	
	public Triangulo(int lado1, int lado2, int lado3)
	{
		setLado1(lado1);
		setLado2(lado2);
		setLado3(lado3);
		
	}
	
	//setters
	public void setLado1(int lado1)
	{
		this.lado1 = lado1;
	}
	
	public void setLado2(int lado2)
	{
		this.lado2 = lado2;
	}
	
	public void setLado3(int lado3)
	{
		this.lado3 = lado3;
	}
	
	//getters
	public int getLado1()
	{
		return this.lado1;
	}
	
	public int getLado2()
	{
		return this.lado2;
	}
	
	public int getLado3()
	{
		return this.lado3;
	}
	
	public void imprimeTipo()
	{
		if (getLado1() == getLado2() && getLado2() == getLado3())
			System.out.println("Tri�ngulo Equil�tero");
		else if (getLado1() != getLado2() && 
				getLado2() != getLado3() &&
				getLado1() != getLado3()
				)
			System.out.println("Tri�ngulo Escaleno");
		else
			System.out.println("Tri�ngulo Is�celes");
	}
}
