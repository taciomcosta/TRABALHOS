package exe05;

public class Estoque 
{
	//Atributos
	private String nome;
	private int qtdAtual;
	private int qtdMinima;
	
	//M�todos
	//construtores
	public Estoque()
	{
		
	}
	
	public Estoque(int qtdAtual, int qtdMinima)
	{
		this.qtdAtual = qtdAtual;
		this.qtdMinima = qtdMinima;
	}
	
	//outros
	public void mudarNome(String nome)
	{
		this.nome = nome;
	}
	
	public void mudarQtdMinima(int qtdMinima)
	{
		if (qtdMinima >= 0)
			this.qtdMinima = qtdMinima;
	}
	
	public void repor(int qtd)
	{
		if (this.qtdAtual + qtd >= 0)
			this.qtdAtual += qtd;
	}
	
	public void darBaixa(int qtd)
	{
		if (this.qtdAtual - qtd >= 0)
			this.qtdAtual -= qtd;
	}
	
	public String mostra()
	{
		String info = "\nNome: " + this.nome + "\n" + 
					  "Quantidade M�nima: " + this.qtdMinima + "\n" +
					  "Quantidade Atual: " + this.qtdAtual + "\n";
		return info;
	}
	
	public boolean precisaRepor()
	{
		if (this.qtdAtual < this.qtdMinima)
			return true;
		else
			return false;
	}
}
