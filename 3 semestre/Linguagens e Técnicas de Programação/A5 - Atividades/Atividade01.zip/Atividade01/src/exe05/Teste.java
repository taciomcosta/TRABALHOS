package exe05;

import java.util.Scanner;

public class Teste 
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		Estoque e = new Estoque(1000, 50);
		
		System.out.print("Mudar nome: ");
		e.mudarNome(input.nextLine());
		System.out.println(e.mostra());
		
		System.out.print("Mudar quantidade m�nima: ");
		e.mudarQtdMinima(input.nextInt());
		System.out.println(e.mostra());
		
		System.out.print("Repor: ");
		e.repor(input.nextInt());
		System.out.println(e.mostra());
		
		System.out.print("Dar baixa: ");
		e.darBaixa(input.nextInt());
		System.out.println(e.mostra());
		
		System.out.println("Precisa repor: " + e.precisaRepor());
		
	}
}
