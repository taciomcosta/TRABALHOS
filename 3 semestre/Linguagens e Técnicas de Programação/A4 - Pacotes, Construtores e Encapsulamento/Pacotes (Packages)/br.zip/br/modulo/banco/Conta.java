package br.modulo.banco;

public class Conta {

}
