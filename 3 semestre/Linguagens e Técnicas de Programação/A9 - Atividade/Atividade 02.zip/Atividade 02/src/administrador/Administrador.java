package administrador;

import empregado.Empregado;

public class Administrador extends Empregado
{
	// ATRIBUTOS
	private double ajudaDeCusto;
	
	// M�TODOS
	// setters e getters
	public void setAjudaDeCusto(double ajudaDeCusto)
	{
		this.ajudaDeCusto = ajudaDeCusto;
	}
	
	public double getAjudaDeCusto()
	{
		return this.ajudaDeCusto;
	}
	
	//outros
	@Override
	public double calcularSalario()
	{
		return super.calcularSalario() + getAjudaDeCusto();
	}
	
	@Override
	public String toString()
	{
		String s = "Administrador = {" + getAjudaDeCusto() + "}";
		
		return super.toString() + s;
	}
}
