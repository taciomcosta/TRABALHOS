package principal;

import pessoa.Pessoa;
import fornecedor.Fornecedor;
import empregado.Empregado;
import administrador.Administrador;
import operador.Operador;
import vendedor.Vendedor;

public class Principal
{
	public static void main(String[] args)
	{	
		double salario;
		
		// PESSOA
		Pessoa pessoa = new Pessoa("T�cio I", "Rua Conde", "1111-1111");
		System.out.println(pessoa);
		System.out.println();
		
		// FORNECEDOR
		Fornecedor fornecedor = new Fornecedor();
		fornecedor.setNome("T�cio II");
		fornecedor.setEndereco("Rua2");
		fornecedor.setTelefone("2222-2222");
		fornecedor.setValorCredito(200);
		fornecedor.setValorDivida(100.50);
		System.out.println(fornecedor);
		System.out.println();
		
		// EMPREGADOR
		Empregado empregado = new Empregado();
		empregado.setNome("T�cio III");
		empregado.setEndereco("Rua3");
		empregado.setTelefone("3333-3333");
		empregado.setCodigoSetor(123);
		empregado.setImposto(0.5);
		empregado.setSalarioBase(1000);
		System.out.println(empregado);
		salario = empregado.calcularSalario();
		System.out.println("Com imposto: " + salario);
		System.out.println();
		
		// ADMINISTRADOR
		Administrador administrador = new Administrador();
		administrador.setNome("T�cio IV");
		administrador.setEndereco("Rua4");
		administrador.setTelefone("4444-4444");
		administrador.setCodigoSetor(321);
		administrador.setImposto(0.5);
		administrador.setSalarioBase(1000);
		administrador.setAjudaDeCusto(200);
		System.out.println(administrador);
		salario = administrador.calcularSalario();
		System.out.println("Com ajuda de custo: " + salario);
		System.out.println();
		
		// OPERARIO
		Operador operador = new Operador();
		operador.setNome("T�cio V");
		operador.setEndereco("Rua5");
		operador.setTelefone("5555-5555");
		operador.setCodigoSetor(111);
		operador.setImposto(0.5);
		operador.setSalarioBase(1000);
		operador.setComissao(0.3);
		System.out.println(operador);
		salario = operador.calcularSalario();
		System.out.println("Com comiss�o: " + salario);
		System.out.println();
		
		//VENDEDOR
		Vendedor vendedor = new Vendedor();
		vendedor.setNome("T�cio VI");
		vendedor.setEndereco("Rua6");
		vendedor.setTelefone("6666-6666");
		vendedor.setCodigoSetor(222);
		vendedor.setImposto(0.5);
		vendedor.setValorVendas(600);
		vendedor.setComissao(0.3);
		System.out.println(vendedor);
		salario = vendedor.calcularSalario();
		System.out.println("Com comiss�o: " + salario);
	}
}