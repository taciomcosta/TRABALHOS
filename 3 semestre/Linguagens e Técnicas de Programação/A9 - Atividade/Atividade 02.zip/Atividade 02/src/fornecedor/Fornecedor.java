package fornecedor;

import pessoa.Pessoa;

public class Fornecedor extends Pessoa
{
	// ATRIBUTOS
	private double valorCredito;
	private double valorDivida;
	
	// M�TODOS
	//setters e getters
	public void setValorCredito(double valorCredito)
	{
		this.valorCredito =  valorCredito;
	}
	
	public double getValorCredito()
	{
		return this.valorCredito;
	}
	
	public void setValorDivida(double valorDivida)
	{
		this.valorDivida = valorDivida;
	}
	
	public double getValorDivida()
	{
		return this.valorDivida;
	}
	
	// outros
	public double obterSaldo()
	{
		return getValorCredito() - getValorDivida();
	}
	
	@Override
	public String toString()
	{
		String s = "Fornecedor = {" + getValorCredito() + "," +
				getValorDivida() + "}";
		return super.toString() + " " + s;
	}
}
