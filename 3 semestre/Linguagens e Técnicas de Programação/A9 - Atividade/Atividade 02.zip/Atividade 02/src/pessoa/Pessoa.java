package pessoa;

public class Pessoa 
{
	// ATRIBUTOS
	private String nome;
	private String endereco;
	private String telefone;
	
	// M�TODOS
	//construtor
	public Pessoa(){}
	public Pessoa(String nome, String endereco, String telefone)
	{
		setNome(nome);
		setEndereco(endereco);
		setTelefone(telefone);
	}
	
	//setters e getters
	public void setNome(String nome)
	{
		this.nome = nome;
	}
	
	public String getNome()
	{
		return this.nome;
	}
	
	public void setEndereco(String endereco)
	{
		this.endereco = endereco;
	}
	
	public String getEndereco()
	{
		return this.endereco;
	}
	
	public void setTelefone(String telefone)
	{
		this.telefone = telefone;
	}
	
	public String getTelefone()
	{
		return this.telefone;
	}
	
	@Override
	public String toString()
	{
		String s = "Pessoa = {" + getNome() + ", " +
				getEndereco() + ", " +
				getTelefone() + "}";
		return s;
	}
	
}
