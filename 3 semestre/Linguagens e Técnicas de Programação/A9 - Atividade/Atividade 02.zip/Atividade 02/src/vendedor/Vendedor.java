package vendedor;

import empregado.Empregado;

public class Vendedor extends Empregado
{
	// ATRIBUTOS
	private double valorVendas;
	private double comissao;
	
	//M�TODOS
	//setters e getters
	public void setValorVendas(double valorVendas)
	{
		this.valorVendas = valorVendas;
	}
	public double getValorVendas()
	{
		return valorVendas;
	}
	
	public void setComissao(double comissao)
	{
		this.comissao = comissao;
	}
	
	public double getComissao()
	{
		return comissao;
	}
	
	//outros
	@Override
	public double calcularSalario()
	{
		double comissao = getComissao();
		double valorVendas = getValorVendas();
		
		return super.calcularSalario() + comissao * valorVendas;
	}
	
	@Override
	public String toString()
	{
		String s = "Vendedor = {" + getValorVendas() + ", " +
				getComissao() + "}";
		
		return super.toString() + s;
	}
	
	
	
	
}
