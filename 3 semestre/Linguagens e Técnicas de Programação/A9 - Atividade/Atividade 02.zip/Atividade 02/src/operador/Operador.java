package operador;

import empregado.Empregado;

public class Operador extends Empregado
{
	// ATRIBUTOS
	private double valorProducao;
	private double comissao;
	
	//M�TODOS
	//setters e getters
	public void setValorProducao(double valorProducao)
	{
		this.valorProducao = valorProducao;
	}
	
	public double getValorProducao()
	{
		return valorProducao;
	}
	
	public void setComissao(double comissao)
	{
		this.comissao = comissao;
	}
	
	public double getComissao()
	{
		return comissao;
	}
	
	//outros
	@Override
	public double calcularSalario()
	{
		double comissao = getComissao();
		double valorProducao = getValorProducao();
		
		return super.calcularSalario() + comissao * valorProducao;
	}
	
	@Override
	public String toString()
	{
		String s = "Operador = {" + getComissao() + "}";
		return super.toString() + s;
	}
}
