package empregado;

import pessoa.Pessoa;

public class Empregado extends Pessoa
{
	// ATRIBUTOS
	protected int codigoSetor;
	protected double salarioBase;
	protected double imposto;
	
	// M�TODOS
	// setters e getters
	public void setCodigoSetor(int codigoSetor)
	{
		this.codigoSetor = codigoSetor;
	}
	
	public int getCodigoSetor()
	{
		return this.codigoSetor;
	}
	
	public void setSalarioBase(double salarioBase)
	{
		this.salarioBase = salarioBase;
	}
	
	public double getSalarioBase()
	{
		return this.salarioBase;
	}
	
	public void setImposto(double imposto)
	{
		this.imposto = imposto;
	}
	
	public double getImposto()
	{
		return this.imposto;
	}
	
	// outros
	public double calcularSalario()
	{
		return getSalarioBase() * (1 - getImposto());
	}
	
	@Override
	public String toString()
	{
		String s = "Empregador = {" + getCodigoSetor() + ", " +
				getSalarioBase() + ", " +
				getImposto() + "}";
		
		return super.toString() + " " + s;
	}
	
}
